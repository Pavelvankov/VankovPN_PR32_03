package com.example.vankovpn_pr_32_03

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Result : AppCompatActivity() {
    lateinit var metr:TextView
    lateinit var result:TextView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        metr = findViewById(R.id.metr)
        result = findViewById(R.id.result)
        metr.text = intent.getIntExtra("count", 0).toString()
        result.text = intent.getIntExtra("result", 0).toString() + "руб."

    }
    fun start(view: View) {
        var intent = Intent(this, FlatBank::class.java)
        startActivity(intent)
    }

}