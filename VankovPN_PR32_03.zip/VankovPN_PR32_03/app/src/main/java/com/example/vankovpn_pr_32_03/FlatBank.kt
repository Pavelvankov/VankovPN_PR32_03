package com.example.vankovpn_pr_32_03

import android.annotation.SuppressLint
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import android.content.Intent

class FlatBank : AppCompatActivity() {
    lateinit var login: EditText
    lateinit var password: EditText
    lateinit var shar:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_flatbank)
        login = findViewById(R.id.login)
        password = findViewById(R.id.password)
        shar = getSharedPreferences("data", MODE_PRIVATE)
        var correctlogin = shar.getString("login", null)
        var correctpassword = shar.getString("password", null)
        if (correctlogin != null && correctpassword != null)
        {
            login.setText(correctlogin)
            password.setText(correctpassword)
        }
    }

    @SuppressLint("SuspiciousIndentation")
    fun vhod(view: View) {
        var log = login.text.toString()
        var pass = password.text.toString()
        shar = getSharedPreferences("data", MODE_PRIVATE)
        if (log.isEmpty() || pass.isEmpty())
        {
            Toast.makeText(this, "Введите логин и пароль", Toast.LENGTH_SHORT).show()
        }
        else if (pass.length < 6)
        {
            Toast.makeText(this, "Для ввода пароля необходимо минимум 6 символов", Toast.LENGTH_SHORT).show()
        }
        else
        {
            shar = getSharedPreferences("data", MODE_PRIVATE)
            var correctlogin = shar.getString("login", null)
            var correctpassword = shar.getString("password", null)
                if (correctlogin != null && correctpassword != null)
                {
                    if (correctlogin == log && correctpassword == pass)
                    {
                        var intent = Intent(this, Apartments::class.java)
                        startActivity(intent)
                    }
                    else
                    {
                        Toast.makeText(this, "Неверный логин или пароль", Toast.LENGTH_SHORT).show()
                    }
                }
            else
                {
                    var edit = shar.edit()
                    edit.putString("login", log)
                    edit.putString("password", pass)
                    edit.apply()
                }

        }
    }
}