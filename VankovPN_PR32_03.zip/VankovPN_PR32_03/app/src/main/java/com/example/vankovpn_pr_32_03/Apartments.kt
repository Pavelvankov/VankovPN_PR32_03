package com.example.vankovpn_pr_32_03

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Apartments : AppCompatActivity() {
    lateinit var spinner: Spinner
    lateinit var metr: EditText

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apartments)

        spinner = findViewById(R.id.spinner)
        metr = findViewById(R.id.metr)

        // Типы квартир
        val apartmentTypes = arrayOf("1-комнатная квартира", "2-комнатная квартира", "3-комнатная квартира", "Студия")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, apartmentTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    fun back(view: View) {
        val intent = Intent(this, FlatBank::class.java)
        startActivity(intent)
    }

    fun result(view: View) {
        if (metr.text.toString().isEmpty()) {
            Toast.makeText(this, "Введите количество метров", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val metrs = metr.text.toString().toInt()

            if (metrs < 10 || metrs > 200) {
                Toast.makeText(this, "Введите количество метров корректно (10-200)", Toast.LENGTH_SHORT).show()
                return
            }


            val costPerMeter = 100000 // 100 тыс. рублей за метр

            val selectedApartmentType = spinner.selectedItemPosition
            val result = when (selectedApartmentType) {
                0 -> (costPerMeter * metrs * 1.4).toInt() // 1-комнатная
                1 -> costPerMeter * metrs                  // 2-комнатная
                2 -> (costPerMeter * metrs * 0.8).toInt()  // 3-комнатная
                3 -> (costPerMeter * metrs * 1.1).toInt()  // Студия
                else -> 0
            }


            val intent = Intent(this, Result::class.java)
            intent.putExtra("count", metrs)
            intent.putExtra("apartmentType", spinner.selectedItem.toString())
            intent.putExtra("result", result)
            startActivity(intent)

        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Введите корректное число", Toast.LENGTH_SHORT).show()
        }
    }
}