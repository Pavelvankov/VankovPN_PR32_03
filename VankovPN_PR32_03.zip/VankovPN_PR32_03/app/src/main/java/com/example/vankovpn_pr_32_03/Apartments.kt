package com.example.vankovpn_pr_32_03

import android.annotation.SuppressLint
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Apartments : AppCompatActivity() {
    lateinit var spinner: Spinner
    lateinit var metr: EditText
    lateinit var res: TextView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apartments)

        spinner = findViewById(R.id.spinner)
        metr = findViewById(R.id.metr)
        res = findViewById(R.id.result)


        val districts = arrayOf("Центральный", "Спальный", "Промышленный", "Деловой")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, districts)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
    }

    fun back(view: View) {
        val intent = Intent(this, FlatBank::class.java)
        startActivity(intent)
    }

    fun result(view: View) {
        if (metr.text.toString().isEmpty()) {
            Toast.makeText(this, "Введите количество метров", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val metrs = metr.text.toString().toInt()

            if (metrs < 8 || metrs > 200) {
                Toast.makeText(this, "Введите количество метров корректно (8-200)", Toast.LENGTH_SHORT).show()
                return
            }

            val one_m = 123456
            val spin = spinner.selectedItemPosition
            val result = when (spin) {
                0 -> (one_m * metrs * 1.4).toInt()
                1 -> one_m * metrs
                2 -> (one_m * metrs * 0.8).toInt()
                3 -> (one_m * metrs * 1.1).toInt()
                else -> 0
            }

            val intent = Intent(this, Result::class.java)
            intent.putExtra("count", metrs)
            intent.putExtra("result", result)
            startActivity(intent)

        } catch (e: NumberFormatException) {
            Toast.makeText(this, "Введите корректное число", Toast.LENGTH_SHORT).show()
        }
    }
}